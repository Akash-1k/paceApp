export const SHOW_LOADING_VIEW = 'show_loading_view';
export const HIDE_LOADING_VIEW = 'hide_loading_view';
export const HIDE_ERROR_MODAL = 'hide_error_modal';
