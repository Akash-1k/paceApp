const Colors = {
  PrimaryColor: '#C03C32',
  background: '#ffffff',
  fontColor:'#040404',
  lightColor:'#C4C4C4',
  shadowColor:"#1050e6",
  colorGray:'gray',
  themeBG:'#E5E5E5',
  background1:'#F5F6FC',
  transparent:'#0003',
  colorBlack:'#3E4958',
};
export default Colors;
