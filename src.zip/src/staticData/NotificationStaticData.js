export const notificationData = [
  {
    url: require('../../assets/images/shop3.png'),
    title: 'Your order arriving soon',
    subtitle: 'Bershka Mom Jeans',
    orderId: '0706502',
    time: 'Just Now',
  },
  {
    url: require('../../assets/images/LogoBlack.png'),
    title: 'Congratulations',
    subtitle: 'You have finished Your Workout See what’s next workout is!!!!',
    // orderId: '0706502',
    time: '2 mins ago',
  },
  {
    url: require('../../assets/images/pro1.png'),
    title: 'Alert New Update is here',
    // subtitle: 'Bershka Mom Jeans',
    // orderId: '0706502',
    time: '1 hour ago',
  },
];
